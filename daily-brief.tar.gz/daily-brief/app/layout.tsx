import type { Metadata } from "next";
import type { ReactNode } from "react";

export const metadata: Metadata = {
  title: "Daily Brief",
  description: "A private daily reading brief",
  robots: { index: false, follow: false },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <style>{`
          :root { --bg:#fbfaf7; --fg:#1b1b1a; --muted:#6b6a66; --line:#e4e1d8; --link:#1d4ed8; }
          @media (prefers-color-scheme: dark) {
            :root { --bg:#161615; --fg:#ecebe7; --muted:#9a9890; --line:#2b2b29; --link:#8fb4ff; }
          }
          * { box-sizing: border-box; }
          body { margin:0; background:var(--bg); color:var(--fg);
                 font:17px/1.65 Georgia, "Times New Roman", serif; }
          main { max-width: 700px; margin: 0 auto; padding: 32px 18px 80px; }
          h1 { font-size: 1.1rem; letter-spacing:.08em; text-transform:uppercase;
               font-family: system-ui, sans-serif; color: var(--muted); font-weight:600; }
          h2 { font-size: 1.25rem; margin-top: 2.2em; padding-top: .8em;
               border-top: 1px solid var(--line); }
          a { color: var(--link); }
          nav { font: 14px system-ui, sans-serif; color: var(--muted);
                display:flex; flex-wrap:wrap; gap:10px 14px; margin: 14px 0 28px; }
          nav a { color: var(--muted); text-decoration: none; }
          nav a[aria-current="page"] { color: var(--fg); font-weight: 600; }
          li { margin: .5em 0; }
        `}</style>
      </head>
      <body>{children}</body>
    </html>
  );
}
