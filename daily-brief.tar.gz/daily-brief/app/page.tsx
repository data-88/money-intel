import { list } from "@vercel/blob";
import ReactMarkdown from "react-markdown";

export const dynamic = "force-dynamic";

export default async function Home({
  searchParams,
}: {
  searchParams: Promise<{ d?: string }>;
}) {
  const { d } = await searchParams;

  let briefs: { date: string; url: string }[] = [];
  try {
    const { blobs } = await list({ prefix: "briefs/" });
    briefs = blobs
      .map((b) => ({ date: b.pathname.replace("briefs/", "").replace(".md", ""), url: b.url }))
      .sort((a, b) => b.date.localeCompare(a.date));
  } catch {
    // Blob store not connected yet.
  }

  if (briefs.length === 0) {
    return (
      <main>
        <h1>Daily Brief</h1>
        <p>No briefs yet. Trigger the first one by opening <code>/api/cron</code> once
        (send the <code>Authorization: Bearer &lt;CRON_SECRET&gt;</code> header if you set a secret),
        or wait for the scheduled run.</p>
      </main>
    );
  }

  const current = briefs.find((b) => b.date === d) ?? briefs[0];
  const markdown = await fetch(current.url, { cache: "no-store" }).then((r) => r.text());

  return (
    <main>
      <h1>Daily Brief · {current.date}</h1>
      <nav>
        {briefs.slice(0, 14).map((b) => (
          <a key={b.date} href={`/?d=${b.date}`} aria-current={b.date === current.date ? "page" : undefined}>
            {b.date}
          </a>
        ))}
      </nav>
      <ReactMarkdown>{markdown}</ReactMarkdown>
    </main>
  );
}
