import { put } from "@vercel/blob";
import { collectAll } from "@/lib/collect";
import { writeBrief } from "@/lib/brief";

export const maxDuration = 300;
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  // Vercel Cron sends "Authorization: Bearer $CRON_SECRET" when CRON_SECRET is set.
  const secret = process.env.CRON_SECRET;
  if (secret && req.headers.get("authorization") !== `Bearer ${secret}`) {
    return new Response("Unauthorized", { status: 401 });
  }

  const items = await collectAll();
  if (items.length === 0) {
    return Response.json({ ok: false, reason: "no items collected" }, { status: 200 });
  }

  const markdown = await writeBrief(items);
  const date = new Date().toISOString().slice(0, 10);

  const blob = await put(`briefs/${date}.md`, markdown, {
    access: "public",
    contentType: "text/markdown; charset=utf-8",
    addRandomSuffix: false,
    allowOverwrite: true,
  });

  return Response.json({ ok: true, date, items: items.length, url: blob.url });
}
