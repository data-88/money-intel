# Daily Brief

A small agent that runs every morning on Vercel. It pulls free feeds and SEC filings, has Claude
filter them into a short brief (signals, filings worth opening, commentary, deals, questions to chase),
and saves it to a page you can open on any device.

```
Vercel Cron (daily) → /api/cron → collect feeds + EDGAR → Claude writes brief → Vercel Blob → /
```

## Deploy

1. Push this folder to a GitHub repo and import it at vercel.com/new.
2. In the project, go to **Storage** and create a **Blob** store, then connect it to the project.
   This adds `BLOB_READ_WRITE_TOKEN` for you.
3. Add these environment variables (see `.env.example`):
   - `ANTHROPIC_API_KEY`
   - `SEC_USER_AGENT`: SEC requires a real contact, e.g. `DailyBrief Your Name you@example.com`
   - `CRON_SECRET`: any long random string. Vercel Cron sends it automatically.
4. Deploy. The cron in `vercel.json` runs at 12:00 UTC (6am US Central in winter, 7am in summer).
5. To generate the first brief right away, call the endpoint once:
   ```
   curl -H "Authorization: Bearer $CRON_SECRET" https://YOUR-APP.vercel.app/api/cron
   ```
   Then open your site's root URL.

## Make it yours

Everything is in `lib/sources.ts`:

- **`FEEDS`**: add or remove RSS/Atom feeds. Broken feeds are skipped, not fatal.
- **`WATCHLIST`** (env var): comma-separated tickers, e.g. `NVDA,MSFT`. Adds each company's latest EDGAR filings.
- **`BRIEF_FOCUS`** (env var): one or two sentences about what you care about. This steers the whole brief.
- **`LOOKBACK_HOURS`**: how far back to look (default 36).

The writing instructions (section layout, tone, rules) are the `SYSTEM` prompt in `lib/brief.ts`.

Set `ENABLE_WEB_SEARCH=1` to let Claude run up to 5 web searches per run to chase leads. It costs a bit more.

## Things to know

- **Privacy:** the page and the stored briefs are not password-protected. The site sets `noindex`,
  but anyone with the URL can read it. If that matters, turn on Vercel's deployment protection or add auth.
- **Paid newsletters:** RSS only exposes what the publisher makes free (often just a preview or the weekly
  article). The brief can only summarize what's in the feed. If you want full paid content,
  the next step is forwarding newsletters to an inbound email address that the agent also reads.
- **Cost:** one Claude call per day over ~150 short items, usually a few cents.
- **Runtime:** the function is capped at 300s (`maxDuration` in `app/api/cron/route.ts`).

## Run locally

```
npm install
cp .env.example .env.local   # fill in keys
npm run dev
# in another terminal:
curl -H "Authorization: Bearer $CRON_SECRET" http://localhost:3000/api/cron
```

Local runs also need a Blob token (`vercel env pull` after connecting the store).
